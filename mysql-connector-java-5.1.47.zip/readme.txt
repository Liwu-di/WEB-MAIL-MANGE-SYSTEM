This is a java web project. And this is the first time I use git. 
This project needs Tomcat 9.0, MySQL 8.0, and JDK 1.8.
I use eclipse to complete it, so I suggest you to use it, thank you.
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
